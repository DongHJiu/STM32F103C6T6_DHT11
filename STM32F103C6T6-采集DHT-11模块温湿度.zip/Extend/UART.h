#ifndef __USAR_H
#define __USAR_H


void UART_Init(void);
void NVIC_USART1(void);
void USART1_First(uint8_t data);
void USART1_Second(uint16_t data);
void USART1_Array(uint8_t *data,uint8_t num);
void USART1_Str(uint8_t *Str);

#endif
