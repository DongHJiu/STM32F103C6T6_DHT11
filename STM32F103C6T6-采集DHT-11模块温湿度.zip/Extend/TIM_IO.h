#ifndef __TIM_IO_H
#define __TIM_IO_H

void TIM2_Init2(void);

extern u8 TIM_data;
extern u16 data;
extern u8 NAW_Por;

#endif
